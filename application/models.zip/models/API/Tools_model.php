

         public function getToolsDetails($user_id, $page_count, $page_offset, $job_id){ 
          $sql = "SELECT * FROM `tools` WHERE `user_id` = $user_id and `job_id` = $job_id LIMIT $page_count OFFSET $page_offset";
          $query= $this->db->query($sql);

          $data = array();
          $i = 0;
          foreach ($query->result_array() as $row) {
            // $data[$i]['id'] = $row['id'];
            // $data[$i]['user_id'] = $row['user_id'];
            $data[$i]['item'] = $row['item'];
            $data[$i]['quantity'] = $row['quantity'];
            $data[$i]['condition'] = $row['condition'];
            $i = $i+1;
          }

          return $data; 
        } 


    }
?>
