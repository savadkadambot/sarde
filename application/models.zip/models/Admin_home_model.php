<?php
//     class Admin_home_model extends CI_Model {


// public function getLaboursCount(){
//           return $this->db->count_all('labours_details');
//         }
// }
?>