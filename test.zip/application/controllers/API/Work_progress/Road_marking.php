<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Road_marking extends CI_Controller {

	public function add_item()
	{
		header('Content-type: application/json');
		$this->load->helper('string');

		$access_token = $_POST['access_token'];

		$this->load->model('API/Login_model','API_LOGIN_MODEL');
		$validate_access_token = $this->API_LOGIN_MODEL->checkAccessTokenIsValid($access_token);
		if(!is_array($validate_access_token)){
			$response = array();
			$response['result'] = 'invalid_access_token';
			$response['status'] = 'failed';
			echo json_encode($response);
			die();
		}

		$user_id = $validate_access_token['user_id'];

		$post_data = array(
			'user_id' => $user_id,
			'item_description' => $_POST['item_description'],
			'no' => $_POST['no'],
			'length' => $_POST['length'],
			'width' => $_POST['width'],
			'meter_sqr' => $_POST['meter_sqr']
		);

		$this->load->model('API/Work_progress/Road_marking_model','API_ROAD_MARKING_MODEL');
		$add_item = $this->API_ROAD_MARKING_MODEL->addItem($post_data);

		if($add_expense === true){
			$response = array();
			$response['result'] = 'item_added_successfully';
			$response['status'] = 'success';
		}else{
			$response = array();
			$response['result'] = 'failed_to_add_the_item';
			$response['status'] = 'failed';
		}
		echo json_encode($response);
		die();
	}
	
}
