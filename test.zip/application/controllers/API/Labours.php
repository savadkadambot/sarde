<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Labours extends CI_Controller {

	public function add_labours()
	{
		header('Content-type: application/json');
		$this->load->helper('string');

		$access_token = $_POST['access_token'];

		$this->load->model('API/Login_model','API_LOGIN_MODEL');
		$validate_access_token = $this->API_LOGIN_MODEL->checkAccessTokenIsValid($access_token);
		if(!is_array($validate_access_token)){
			$response = array();
			$response['result'] = 'invalid_access_token';
			$response['status'] = 'failed';
			echo json_encode($response);
			die();
		}

		$user_id = $validate_access_token['user_id'];

		$post_data = array(
			'user_id' => $user_id,
			'name' => $_POST['name'],
			'trade' => $_POST['trade'],
			'type' => $_POST['type'],
			'hours' => $_POST['hours']
		);

		$this->load->model('API/Labours_model','API_LABOURS_MODEL');
		$add_labours = $this->API_LABOURS_MODEL->addLabours($post_data);

		if($add_labours === true){
			$response = array();
			$response['result'] = 'expense_added_successfully';
			$response['status'] = 'success';
		}else{
			$response = array();
			$response['result'] = 'failed_to_add_the_expense';
			$response['status'] = 'failed';
		}
		echo json_encode($response);
		die();
	}
	
}
