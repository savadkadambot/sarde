<?php

	
defined('BASEPATH') OR exit('No direct script access allowed');

class Jobs extends CI_Controller {
	
	public function index()
	{
		// if(!isset($_SESSION['super_admin_logged_data'])){
		// 	$redirect_url = base_url();
		// 	redirect($redirect_url, 'refresh');
		// }

		// ini_set('display_errors', 1);
		// ini_set('display_startup_errors', 1);
		// error_reporting(E_ALL);

		$this->load->model('Labours_model'); 

         $data['get_labours_details']=$this->Labours_model->getLaboursDetails();
        
			$this->load->view('jobs/jobs_list',$data);

	}




	public function create_job(){
		// if(!isset($_SESSION['super_admin_logged_data'])){
		// 	$redirect_url = base_url();
		// 	redirect($redirect_url, 'refresh');
		// }
		// ini_set('display_errors', 1);
		// ini_set('display_startup_errors', 1);
		// error_reporting(E_ALL);

		// if($_POST){

		// 	$data = array();
		// 	$data['name'] = $_POST['name'];
		// 	$data['mobile'] = $_POST['mobile'];
		// 	$data['trade'] = $_POST['trade'];
		// 	$data['status'] = $_POST['status'];


		// 	$this->load->model('Labours_model');
		// 	$add_labours = $this->Labours_model->addlabours($data);
			
		// 	if($add_labours){
		// 		redirect('Labours/index');			 
		// 		}
		//   }
      

		$this->load->view('jobs/create_job');

			}

	// 	public function delete_labours($id){
	// 		if(!isset($_SESSION['super_admin_logged_data'])){
	// 		$redirect_url = base_url();
	// 		redirect($redirect_url, 'refresh');
	// 	}
	// 		$this->db->where('id', $id);
	//     	$delete = $this->db-> delete('labours_details');
	// 		redirect('Labours/index');
	// }
}
?>

