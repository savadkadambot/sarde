<?php

	
defined('BASEPATH') OR exit('No direct script access allowed');

class Labours extends CI_Controller {
	
	public function index()
	{
		if(!isset($_SESSION['super_admin_logged_data'])){
			$redirect_url = base_url();
			redirect($redirect_url, 'refresh');
		}

		ini_set('display_errors', 1);
		ini_set('display_startup_errors', 1);
		error_reporting(E_ALL);

		$this->load->model('Labours_model'); 

         $data['get_labours_details']=$this->Labours_model->getLaboursDetails();
        
			$this->load->view('labours/labours_list',$data);		
	}




	public function add_labours(){
		if(!isset($_SESSION['super_admin_logged_data'])){
			$redirect_url = base_url();
			redirect($redirect_url, 'refresh');
		}
		ini_set('display_errors', 1);
		ini_set('display_startup_errors', 1);
		error_reporting(E_ALL);

		if($_POST){

			$data = array();
			$data['name'] = $_POST['name'];
			$data['mobile'] = $_POST['mobile'];
			$data['trade'] = $_POST['trade'];
			$data['status'] = $_POST['status'];


			$this->load->model('Labours_model');
			$add_labours = $this->Labours_model->addlabours($data);
			
			if($add_labours){
				redirect('Labours/index');			 
				}
		  }
      

		$this->load->view('labours/add_labours');

			}

		// public function edit_labours($id){

		// $this->load->model('Labours_model');
		// $data['labours_details_from_id'] = $this->Labours_model->getLaboursDetailsFromId($id);
		// if($_POST){

		// 	// $update_id = $_POST['update_id'];
		// 	$data = array();
		// 	$data['name'] = $_POST['name'];
		// 	$data['mobile'] = $_POST['mobile'];
		// 	$data['trade'] = $_POST['trade'];
		// 	$data['status'] = $_POST['status'];

			
		// 	$update_details = $this->Labours_model->updateLabours($update_id,$data);
		// 	if($update_details){
		// 		// echo "ssss";
		// 		// die();
		// 		redirect('Labours/index');
		// 	}
		// }
		// // $data['list_careers'] = $this->Career_model->listCareers();

		// 		$this->load->view('labours/edit_labours');

		// // $this->load->view('labours/edit_labours',$data);
		// }

		public function delete_labours($id){
			if(!isset($_SESSION['super_admin_logged_data'])){
			$redirect_url = base_url();
			redirect($redirect_url, 'refresh');
		}
			$this->db->where('id', $id);
	    	$delete = $this->db-> delete('labours_details');
			redirect('Labours/index');
	}
}
?>

