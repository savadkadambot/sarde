<?php

	
defined('BASEPATH') OR exit('No direct script access allowed');

class Supervisors extends CI_Controller {
	
	public function index()
	{
		if(!isset($_SESSION['super_admin_logged_data'])){
			$redirect_url = base_url();
			redirect($redirect_url, 'refresh');
		}

		ini_set('display_errors', 1);
		ini_set('display_startup_errors', 1);
		error_reporting(E_ALL);


		$this->load->model('Supervisors_model'); 

		 $data['get_supervisors_details']=$this->Supervisors_model->getSupervisorsDetails();
        
			$this->load->view('supervisors/supervisors_list',$data);			
	}




	public function add_supervisors(){
		
		if(!isset($_SESSION['super_admin_logged_data'])){
			$redirect_url = base_url();
			redirect($redirect_url, 'refresh');
		}

		ini_set('display_errors', 1);
		ini_set('display_startup_errors', 1);
		error_reporting(E_ALL);

		if($_POST){
			$data = array();
			$data['name'] = $_POST['name'];
			$data['email'] = $_POST['email'];
			$data['password'] = $_POST['password'];
			$data['job_code'] = $_POST['job_code'];
			$data['mobile'] = $_POST['mobile'];
			$data['status'] = $_POST['status'];


			$this->load->model('Supervisors_model');

			$add_supervisors = $this->Supervisors_model->addSupervisors($data);
			
			if($add_supervisors){
				redirect('Supervisors/index');			 
				}
		  }
      

		$this->load->view('supervisors/add_supervisors');

}
		public function delete_supervisors($id){
			if(!isset($_SESSION['super_admin_logged_data'])){
			$redirect_url = base_url();
			redirect($redirect_url, 'refresh');
		}
			$this->db->where('id', $id);
	    	$delete = $this->db-> delete('supervisors_details');
			redirect('Supervisors/index');
	}

}
?>

