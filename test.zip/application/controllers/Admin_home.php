<?php

	
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_home extends CI_Controller {
	
	public function index()
	{
		
		// if(!isset($_SESSION['super_admin_logged_data'])){
		// 	$redirect_url = base_url().'index.php/Admin_login/super_admin_login';
		// 	redirect($redirect_url, 'refresh');
		if(!isset($_SESSION['super_admin_logged_data'])){
			$redirect_url = base_url();
			redirect($redirect_url, 'refresh');
		}

		$this->load->view('admin_home/dashboard');	

		// $count["total_rows"] = $this->Admin_home_model->getLaboursCount();
		
	}



	


}
 

