<?php
    class Supervisors_model extends CI_Model
    {
        public function __construct()
        {
                $this->load->database();
        }


         public function addSupervisors($data){

          $add_supervisors = $this->db->insert('supervisors_details',$data);
        
          if($add_supervisors){
            return true;
          }else{
            return false;
          }
        }


        public function getSupervisorsDetails(){ 

        

            $sql = "SELECT * FROM `supervisors_details`";
          $query= $this->db->query($sql);

          $data = array();
          $i = 0;
          foreach ($query->result_array() as $row) {
            $data[$i]['id'] = $row['id'];
            $data[$i]['name'] = $row['name'];
            $data[$i]['email'] = $row['email'];
            $data[$i]['password'] = $row['password'];
            $data[$i]['job_code'] = $row['job_code'];
            $data[$i]['mobile'] = $row['mobile'];
            
            if($row['status']==1){
                $active_status = "Active";
            }else{
                $active_status = "Inactive";
            }
            $data[$i]['status'] = $active_status;
            $data[$i]['created_date'] = $row['created_date'];
            $i = $i+1;
          }

          return $data; 
        }  

        public function deleteSupervisors($id){
          $sql = "UPDATE `supervisors_details` SET `status` = 0 WHERE id = $id";
          $query = $this->db->query($sql);
          if($query){
            return true;
          }else{
            return false;
          }
        }
        


}
?>