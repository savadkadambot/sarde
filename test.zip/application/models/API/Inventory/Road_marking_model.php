<?php
    class Road_marking_model extends CI_Model
    {
        public function __construct()
        {
                $this->load->database();
        }

        public function addItem($post_data){
          $add_item = $this->db->insert('inven_road_marking',$post_data);
          if($add_item){
            return true;
          }else{
            return false;
          }          
        }


    }
?>
