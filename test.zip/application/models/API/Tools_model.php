<?php
    class Tools_model extends CI_Model
    {
        public function __construct()
        {
                $this->load->database();
        }

        public function addTools($post_data){
          $add_tools = $this->db->insert('tools',$post_data);
          if($add_tools){
            return true;
          }else{
            return false;
          }          
        }


    }
?>
